package inheritance.Interface_home_task_dl_07_2018;

public class FootballEvent implements Football, Event {

    private String startDate;
    private String endDate;

    private int goalTeam1;
    private int goalTeam2;

    private String matchScore;


    public FootballEvent() {

        this.startDate = " - ";
        this.endDate = " - ";
        this.goalTeam1 = 0;
        this.goalTeam2 = 0;
        this.matchScore = "Result is: - : - ";

    }

    public FootballEvent(String startDate, String endDate) {

        this.setEventStart(startDate);
        this.setEventEnd(endDate);

        this.goalTeam1 = 0;
        this.goalTeam2 = 0;

        this.matchScore = "Result is: - : - ";
    }


    @Override
    public void setEventStart(String startDate) {

        this.startDate = startDate;

    }

    @Override
    public void setEventEnd(String endDate) {

        this.endDate = endDate;

    }

    @Override
    public String getEventDateTime() {

        return "Football event schedule. From " + this.startDate + " to: " + this.endDate + ".";
    }


    @Override
    public void setGoalScored(int goalTeam1, int goalTeam2) {

        this.goalTeam1 = this.goalTeam1 + goalTeam1;
        this.goalTeam2 = this.goalTeam2 + goalTeam2;

    }

    @Override
    public String getMatchScore() {

        return "Result is: " + this.goalTeam1 + " : " + this.goalTeam2;
    }


}
