package inheritance.Interface_home_task_dl_07_2018;

public class Main {

    public static void main(String[] args) {


        FootballEvent footballEvent1 = new FootballEvent();
        System.out.println(footballEvent1.getMatchScore());
        System.out.println(footballEvent1.getEventDateTime());


        FootballEvent footballEvent2 = new FootballEvent( "01-01-2018, 19:00", "12-01-2018, 20:45"  );

        footballEvent2.setGoalScored( footballEvent2.ADDGOAL, footballEvent2.NOGOAL );
        footballEvent2.setGoalScored( footballEvent2.NOGOAL, footballEvent2.ADDGOAL);

        System.out.println(footballEvent2.getMatchScore());
        System.out.println(footballEvent2.getEventDateTime());


    }
}
