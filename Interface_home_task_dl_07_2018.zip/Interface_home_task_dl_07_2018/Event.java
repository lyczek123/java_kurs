package inheritance.Interface_home_task_dl_07_2018;

public interface Event {

    public void setEventStart(String startDate);
    public void setEventEnd(String endDate);
    public String getEventDateTime();


}
