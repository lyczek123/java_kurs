package inheritance.Interface_home_task_dl_07_2018;

public interface Football {

    public void setGoalScored( int goalTeam1, int goalTeam2 );
    public String getMatchScore();
    public static int ADDGOAL = 1;
    public static int NOGOAL = 0;

}
