package Area_dl_201807;

import static java.lang.Math.*;

public class Figure {

    double area;
    double perimeter;


    public Figure() {

        this.area = 0;
        this.perimeter = 0;


    }


    public double getArea() {

        return area;

    }

}
