package Area_dl_201807;

public class Triangle extends Figure {

    public double basicLenght;
    public double height;

    public double a;
    public double b;
    public double c;


    {
        basicLenght = 0;
        height = 0;

        a = 0;
        b = 0;
        c = 0;
    }

    public double getArea(double basicLenght, double height) {

        area = basicLenght * height / 2;

        return area;

    }

    /**
     * Heron's formula - https://en.wikipedia.org/wiki/Heron%27s_formula
     * @param a
     * @param b
     * @param c
     * @return
     */
    public double getArea(double a, double b, double c) {

        // checking if figure is a triangle
        // a+b>c, a+c>b, b+c>a

        double semiperimeter = (a + b + c) / 2;

        area = Math.sqrt(semiperimeter * (semiperimeter - a) * (semiperimeter - b) * (semiperimeter - c));

        return area;

    }

}
