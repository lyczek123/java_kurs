package Area_dl_201807;

//Pole powierzchni koła ograniczonego okręgiem (sam okrąg ma puste wnętrze, a więc i zerową powierzchnię)
public class Disc extends Figure {



    public double getArea( float radius)  {

        area = Math.pow(radius, 2)  * Math.PI;

        return area;

    }


}
