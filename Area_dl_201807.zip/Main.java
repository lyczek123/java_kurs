package Area_dl_201807;

import java.awt.geom.Area;

public class Main {

    public static void main( String[] args ) {

        System.out.println("Main class: calculating figure area");

        Disc disc1 = new Disc();
        double discArea = disc1.getArea( 2);
        System.out.println( discArea);

        Rectangle rectangle1 = new Rectangle();
        double rectangleArea = rectangle1.getArea( 1,2 );
        System.out.println( rectangleArea);

        Squere squere1 = new Squere();
        double squereArea = squere1.getArea( 2 );
        System.out.println( squereArea);

        try {
            squereArea = squere1.getArea(1, 2);
            System.out.println(squereArea);
        }
        catch (Exception e) {

            System.out.println(e);

        }

        squereArea = squere1.getArea( 3,3 );
        System.out.println( squereArea);


        Triangle triangle1 = new Triangle();
        double triangleArea = triangle1.getArea( 2,1 );
        System.out.println( triangleArea);

        // http://bazywiedzy.com/wzor-herona.html
        triangleArea = triangle1.getArea( 10,12,4 );
        System.out.println( triangleArea );
        // test: below
        //System.out.println( " = " + 3 * Math.sqrt(39));


        // how to calculate using  JAVA libraries ? probably awt.geom is not enough.

    }




}
