package Area_dl_201807;

public class Rectangle extends Figure{

    public double width;
    public double height;

    {
        width = 0;
        height = 0;

    }


    public double getArea( double width, double height)  {

        area = width * height;

        return area;

    }

}
