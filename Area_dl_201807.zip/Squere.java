package Area_dl_201807;

public class Squere extends Rectangle  {

  public double length;

    {
        length = 0;
    }

    public double getArea(  double length )  {

        area = length * length;

        return area;

    }


    public double getArea( double width, double height)  {

            if ( width != height )
            {

                throw new java.lang.RuntimeException("Squere witdth and height must be the same!");
            }

            return  super.getArea(width, height);


    }

}
