package Area_dl_201807;


//Circle doesn't have area
public class Circle {
}
